# QQMusic · Android native third-party prototype (v0.3.1)

> **Not an official QQ Music or Spotify product.** "QQMusic" is a user-requested project name for private development, not a claim of affiliation. The launcher icon has been replaced with the QQ Music brand emblem as requested for a personal prototype; this does not grant trademark rights or imply official affiliation. Its dark, card-based browsing and playback pattern is inspired by modern music apps; no proprietary UI images, code, or Spotify logos are copied; QQ Music logo artwork is included solely for this requested personal app icon.

## Current functionality — real implementation

- **Native Android:** Kotlin, Jetpack Compose, Media3 playback, no WebView shell.
- **Home:** Spotify-style dark home screen with category chips, quick tiles, recent plays, liked music, local music and personal playlists.
- **Library:** scans local MP3/FLAC/etc audio with Android MediaStore after asking runtime permission; play, pause, previous, next, seek and favorite songs.
- **Local playlists:** create, rename, delete, add/remove songs. They and likes/recently played are stored on-device across restarts. Audio files are not duplicated.
- **Now Playing:** cover, interactive seek bar, shuffle, repeat one/all/off, queue selection, mini player, background playback, audio focus / headset-disconnect handling.
- **Lyrics:** choose a local LRC or text file for a specific song; parse timed lyrics and highlight lines based on playback progress. Lyrics remain locally stored.
- **QQ Music public search (experimental):** searches song metadata with pagination, shows album and artist groupings from returned songs, and opens official song details. These are not comprehensive album/artist searches; the endpoint is undocumented and may stop responding.
- **Offline-safe integration:** QQ results can be saved into a *local-only online bookmark collection* (up to 500 items), with recent search terms (up to 12), share sheet and best-effort public lyric preview. All are stored locally and can be deleted from the UI. The app checks for exact-title-and-artist local audio matches and offers a distinct **play local file** action; it never silently misrepresents that as QQ streaming.
- **CI:** GitHub Actions installs Gradle/Android SDK, runs lint and unit tests, creates debug APK. For version tags, can publish a signed release APK **only if signing secrets are provided**; otherwise publishes testing APK as a prerelease.

## What is **not** implemented (do not treat the above as equivalent)

- QQ Music account login, QQ/WeChat identity integration, cloud favorites and cloud playlists, VIP/member status, official online stream URLs, DRM protected music playback, paid content downloads or social comments. The QQ bookmark feature is *not cloud synchronization*.
- Spotify Connect, AI DJ, podcasts, synchronized lyrics from QQ, cross-device streaming, official listening history or Spotify's entire production feature set.
- Any authorized QQ Music API provider credentials: they are not included because the official developer programme requires separately approved access.

These capabilities cannot be made operational merely by copying Spotify's UI. A fully functional QQ Music third-party client would need legitimate service access and explicit integration testing; scraping or breaking DRM is not a substitute.

## Build APK using only a phone (GitHub)

1. Create a **new private** GitHub repository at https://github.com/new, name it `QQMusic`, select **Initialize with README** and create it. (Existing linked GitHub integration can push files into an existing repository, but cannot create repositories itself.)
2. Upload the **contents** of this source folder to the repository root, retaining nested `.github/` and `app/` paths; or share the newly-created repository URL with ChatGPT so the connected GitHub integration can upload this source tree.
3. Pushing to `main` triggers Actions automatically. In **Actions**, look for `QQMusic Android APK` (or use `Run workflow` to retry).
4. On a successful build, download the `QQMusic-v0.3.1-debug-apk` artifact and unzip it to obtain `app-debug.apk`.
5. Open the app and allow audio library permissions. It contains no copyrighted songs and QQ online streaming is not implemented.

**Stable signing:** when ready, create a persistent keystore locally and store it outside GitHub. Put its Base64 content and passwords in repository Actions secrets: `QQMUSIC_KEYSTORE_BASE64`, `QQMUSIC_KEYSTORE_PASSWORD`, `QQMUSIC_KEY_ALIAS`, and `QQMUSIC_KEY_PASSWORD`. Never add `.jks`, passwords, cookies, or QQ tokens to the repository. Tags such as `v0.3.1` then produce a prerelease: the preview debug APK is always attached, and a signed release APK appears only when all four secrets are present. Without these secrets, each hosted debug build can have a different signature and might not install as an update.

## Open-source references and license boundaries

This development version is an original app prototype using the following sources for architectural research (no source files from these projects were pasted into this app):

- [Melodia](https://github.com/rinchao0721/Melodia) — MIT. Native Compose UI patterns, feature modules, Media3, plugin architecture, motion and performance techniques. Its backend is Netease Cloud Music, not QQ Music.
- [Melodist](https://github.com/Viemean/melodist) — MIT. Android phone/TV separation, playback modules, QQ Music-oriented feature boundaries. Its undocumented integrations may break or require authorizations.
- [QQMusicApi](https://github.com/L-1124/QQMusicApi) — GPL-3.0-or-later. API categories and response concepts are documented for reference. This APK does **not** embed or call the Python package. Copying that code into a distributed project requires compliance with the GPL.

Use official authorization for member streaming, paid downloads and account features. Do not ship session secrets or spoof logins. The QQ Music logo is a trademarked asset included at the user's request for a private prototype; publishing it requires appropriate trademark rights.

## Toolchain

Android SDK 36, Android Gradle Plugin 8.11.1, Gradle 8.13, Kotlin 2.2.20, Compose BOM 2026.09.00, Media3 1.11.1, JDK 17. Android 8.0+ supported. Build must be verified in CI; the current execution environment has no Android SDK or dependency download access, so its APK status is not yet verified.

## Design and limitations

The user's desired aesthetic is a green-on-dark streaming layout, small-radius album covers, minimal top filters, compact mini player and full-screen album player. It's a new third-party implementation, not pixel-identical Spotify intellectual property. UI and UX are subject to further refinement after real-device screenshots and performance profiling.

© Independent experimental project. All song and album artwork shown by online search belongs to respective rightsholders. Official player links use `https://y.qq.com`.
