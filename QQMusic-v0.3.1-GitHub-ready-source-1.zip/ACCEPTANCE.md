# Manual acceptance test — QQMusic v0.3.1

Run after CI `lintDebug testDebugUnitTest assembleDebug` passes; confirm on a real Android device.

- [ ] App installs cleanly, shows **QQMusic** (not QPulse), and opens without crashes.
- [ ] Initial user-facing disclaimer available via Home > Settings/Info.
- [ ] Media permission denied: app remains navigable and explains what to do.
- [ ] Media permission granted: MP3/FLAC in Android MediaStore appear; refresh finds new music.
- [ ] Play/Pause, Next/Previous, background audio, lockscreen controls, progress seek and headset unplugging behave as expected.
- [ ] Bottom mini-player responds and opens full playback screen, without overlapping end of list.
- [ ] Shuffle, repeat all, repeat one, repeat off and queue song selection work for a local album.
- [ ] Like/unlike persists after app relaunch; recent plays update when switching tracks.
- [ ] Create playlist, rename, add song, remove song, delete playlist persist after app relaunch; files remain intact.
- [ ] Import an LRC file, check 00:xx timestamps, change song and reopen lyric panel.
- [ ] Online QQ catalogue search returns valid results when endpoint is available; errors are understandable when it is not.
- [ ] Online result opens official QQ Music song detail, never pretends to play an unavailable stream.
- [ ] Notifications and media service behave on Android 8, 13, 15+, in portrait and landscape.
- [ ] Long lyrics, empty library, 1,000+ songs and frequent tab-switching are profiled for jank / memory.
- [ ] APK produced by CI can be downloaded; once release signing is configured, a later APK updates the previous one without wiping data.

The checks above are **pending real-device execution**; they are not claims of passing tests.

## v0.2.1 launcher icon verification
- [x] Standard density launcher PNGs mdpi through xxxhdpi exist
- [x] Android adaptive and round icon resource XMLs exist
- [x] Old app icon is no longer referenced by manifest
- [ ] Launcher icon checked on physical Android device after CI build

## v0.3.0 online metadata and native integration (pending CI/device)

- [ ] Search QQ public songs, tap a result to open its official URL, and confirm text distinguishes this from in-app streaming.
- [ ] Load more results and confirm previous results are retained without duplicates; changing the input text before loading more does not mix queries.
- [ ] Search results group by album/artist only from retrieved songs; filters can be cleared.
- [ ] Tap an online bookmark heart and verify it appears under Library > QQ 曲目收藏; remove from either screen, relaunch and confirm persistence.
- [ ] Deny local-audio permission and verify online bookmarks remain available.
- [ ] Search history appears and can be cleared; no credentials, cookies or tokens are persisted.
- [ ] Tap public lyrics and verify loading, successful display if available, and a helpful failure message otherwise.
- [ ] Match an exact local title + artist, play with the in-app local icon; a different artist with the same title must not be matched.
- [ ] Share a song via Android share sheet; select a missing external app/handler and confirm no crash.
- [ ] Audit licenses and trademark use before publishing.

## v0.3.1 review checks

- [x] Native Android XML resources and manifest parse successfully
- [x] Workflow YAML parses; branch builds do not require publishing permissions; tag release publishing is separated
- [x] Kotlin lyric smoke tests (4 direct checks) pass
- [x] Source ZIP structure and checksums validated
- [ ] CI compiles Gradle Android app and produces a real APK
- [ ] Real Android device installation, playback, streaming failure and performance acceptance tests
- [ ] New QQMusic GitHub repository is created by account owner or enabled repository-create API
