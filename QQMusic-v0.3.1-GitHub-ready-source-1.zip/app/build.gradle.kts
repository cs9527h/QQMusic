plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.shuocao.qqmusic"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.shuocao.qqmusic"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "0.3.1"
    }

    signingConfigs {
        create("stableRelease") {
            val path = System.getenv("QQMUSIC_SIGNING_PATH")
            if (!path.isNullOrBlank()) {
                storeFile = file(path)
                storePassword = System.getenv("QQMUSIC_STORE_PASSWORD")
                keyAlias = System.getenv("QQMUSIC_KEY_ALIAS")
                keyPassword = System.getenv("QQMUSIC_KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        release {
            if (!System.getenv("QQMUSIC_SIGNING_PATH").isNullOrBlank()) {
                require(listOf("QQMUSIC_STORE_PASSWORD", "QQMUSIC_KEY_ALIAS", "QQMUSIC_KEY_PASSWORD")
                    .all { !System.getenv(it).isNullOrBlank() }) {
                    "Release signing secrets are incomplete; refusing to generate an ambiguously signed APK"
                }
                signingConfig = signingConfigs.getByName("stableRelease")
            }
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        resources.excludes.add("/META-INF/{AL2.0,LGPL2.1}")
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2026.09.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    implementation("androidx.media3:media3-exoplayer:1.11.1")
    implementation("androidx.media3:media3-session:1.11.1")
    implementation("io.coil-kt:coil-compose:2.7.0")
    testImplementation("junit:junit:4.13.2")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
