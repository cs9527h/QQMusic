package com.shuocao.qqmusic

import org.junit.Assert.assertEquals
import org.junit.Test

class LyricParserTest {
    @Test fun handlesSecondPrecisionAndHundredths() {
        val lines = LyricParser.parse("[00:01.25]Hi\n[00:02.120]There")
        assertEquals(1250L, lines[0].atMs)
        assertEquals("Hi", lines[0].content)
        assertEquals(2120L, lines[1].atMs)
    }

    @Test fun supportsMultipleTimestampsAndSorting() {
        val lines = LyricParser.parse("[01:02.00]Later\n[00:03.0][00:04.00]Repeat")
        assertEquals(listOf(3000L, 4000L, 62000L), lines.map { it.atMs })
    }

    @Test fun handlesOffsetAndClampsNegativeTimestamps() {
        val lines = LyricParser.parse("[offset:-2000]\n[00:01.00]A\n[00:04.00]B")
        assertEquals(listOf(0L, 2000L), lines.map { it.atMs })
    }

    @Test fun ignoresMalformedSecondsAndMetadata() {
        val lines = LyricParser.parse("[ar:Singer]\n[00:90.00]Bad\n[00:03.00]Valid")
        assertEquals(listOf("Valid"), lines.map { it.content })
    }

    @Test fun plainLyricsRemainReadable() {
        val lines = LyricParser.parse("First\n\nSecond")
        assertEquals(listOf("First", "Second"), lines.map { it.content })
    }
}
