package com.shuocao.qqmusic

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.SubcomposeAsyncImage
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.absoluteValue

private val Base = Color(0xFF101010)
private val Panel = Color(0xFF202020)
private val Elevated = Color(0xFF292929)
private val Accent = Color(0xFF1ED760)
private val Muted = Color(0xFFB0B0B0)
private val Bright = Color(0xFFFDFDFD)
private val gradientPalette = listOf(
    listOf(Color(0xFF397C63), Color(0xFF17392C)),
    listOf(Color(0xFF8D6655), Color(0xFF3E2631)),
    listOf(Color(0xFF6F70A6), Color(0xFF292B52)),
    listOf(Color(0xFF9A7353), Color(0xFF383924)),
    listOf(Color(0xFF6C7996), Color(0xFF1D3243)),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(10, 12, 11)
        window.navigationBarColor = android.graphics.Color.rgb(10, 12, 11)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Accent, onPrimary = Base, background = Base,
                surface = Panel, onSurface = Bright, onBackground = Bright,
                secondary = Accent
            )) {
                MusicApp()
            }
        }
    }
}

private enum class Tab { HOME, SEARCH, LIBRARY }
private enum class LibraryFilter { ALL, LIKED, PLAYLISTS, QQ_SAVED }
private enum class SearchMode { QQ, LOCAL }
private enum class QqGroup { SONGS, ALBUMS, ARTISTS }

@Composable
private fun MusicApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val permission = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    var hasPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED)
    }
    var localSongs by remember { mutableStateOf<List<LocalSong>>(emptyList()) }
    var tab by remember { mutableStateOf(Tab.HOME) }
    var showPlayer by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var libraryFilter by remember { mutableStateOf(LibraryFilter.ALL) }
    val store = remember { MusicStore(context) }
    val onlineStore = remember { OnlineLibraryStore(context) }
    var onlineBookmarks by remember { mutableStateOf(onlineStore.bookmarks()) }
    fun toggleOnlineBookmark(song: QqSong) { onlineBookmarks = onlineStore.toggle(song) }
    var playlists by remember { mutableStateOf(store.playlists()) }
    var history by remember { mutableStateOf(store.history()) }
    var focusedPlaylistId by remember { mutableStateOf<String?>(null) }
    var showCreatePlaylist by remember { mutableStateOf(false) }
    var addSongToPlaylist by remember { mutableStateOf<LocalSong?>(null) }
    var editPlaylist by remember { mutableStateOf<UserPlaylist?>(null) }
    var showQueue by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    var lyricSong by remember { mutableStateOf<Long?>(null) }
    var rawLyric by remember { mutableStateOf("") }
    val lyricPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { reader ->
                val text = reader.readText().take(100_000)
                lyricSong?.let { store.saveLyric(it, text) }
                rawLyric = text
            }
        }.onFailure { /* Unsupported file or revoked grant; keep previous lyrics */ }
    }
    BackHandler(showPlayer || focusedPlaylistId != null || showQueue || showLyrics) {
        when {
            showQueue -> showQueue = false
            showLyrics -> showLyrics = false
            showPlayer -> showPlayer = false
            else -> focusedPlaylistId = null
        }
    }
    val preferences = remember { context.getSharedPreferences("music_library", 0) }
    var likedIds by remember { mutableStateOf(preferences.getStringSet("likes", emptySet())?.toSet().orEmpty()) }
    fun toggleLike(id: Long) {
        likedIds = if (id.toString() in likedIds) likedIds - id.toString() else likedIds + id.toString()
        preferences.edit().putStringSet("likes", likedIds).apply()
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPermission = granted
        if (granted) scope.launch { localSongs = AudioLibrary.load(context) }
    }
    LaunchedEffect(hasPermission) {
        if (hasPermission) {
            localSongs = runCatching { AudioLibrary.load(context) }.getOrDefault(emptyList())
        }
    }

    val token = remember { SessionToken(context, ComponentName(context, PlaybackService::class.java)) }
    val controllerFuture: ListenableFuture<MediaController> = remember {
        MediaController.Builder(context, token).buildAsync()
    }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var playerError by remember { mutableStateOf<String?>(null) }
    DisposableEffect(controllerFuture) {
        var disposed = false
        controllerFuture.addListener({
            if (!disposed) {
                runCatching { controllerFuture.get() }
                    .onSuccess { controller = it }
                    .onFailure { playerError = it.message ?: "播放服务连接失败" }
            }
        }, ContextCompat.getMainExecutor(context))
        onDispose {
            disposed = true
            controller = null
            MediaController.releaseFuture(controllerFuture)
        }
    }

    var activeId by remember { mutableStateOf<Long?>(null) }
    var playing by remember { mutableStateOf(false) }
    var progress by remember { mutableLongStateOf(0L) }
    var length by remember { mutableLongStateOf(0L) }
    var shuffleEnabled by remember { mutableStateOf(false) }
    var repeatModeState by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    DisposableEffect(controller) {
        val c = controller
        if (c == null) {
            onDispose { }
        } else {
            var lastSeenId: Long? = null
            fun snapshot() {
                val current = c.currentMediaItem?.mediaId?.toLongOrNull()
                activeId = current
                if (current != null && current != lastSeenId) {
                    store.recordPlayed(current)
                    history = store.history()
                    lastSeenId = current
                }
                playing = c.isPlaying
                shuffleEnabled = c.shuffleModeEnabled
                repeatModeState = c.repeatMode
                length = c.duration.coerceAtLeast(0L)
                progress = c.currentPosition.coerceAtLeast(0L)
            }
            val listener = object : Player.Listener {
                override fun onEvents(player: Player, events: Player.Events) = snapshot()
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    playerError = error.localizedMessage ?: "无法播放该文件"
                }
            }
            c.addListener(listener)
            snapshot()
            onDispose { c.removeListener(listener) }
        }
    }
    LaunchedEffect(controller, playing) {
        while (true) {
            progress = controller?.currentPosition?.coerceAtLeast(0L) ?: 0L
            delay(if (playing) 400 else 1200)
        }
    }
    val activeSong = remember(localSongs, activeId) { localSongs.firstOrNull { it.id == activeId } }
    fun playSong(song: LocalSong, queue: List<LocalSong>) {
        val c = controller ?: run { playerError = "播放器正在初始化，请重试"; return }
        val list = queue.ifEmpty { listOf(song) }
        val index = list.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
        val items = list.map { item ->
            val artwork = if (item.albumId > 0) ContentUris.withAppendedId(
                Uri.parse("content://media/external/audio/albumart"), item.albumId
            ) else null
            MediaItem.Builder().setMediaId(item.id.toString()).setUri(item.uri)
                .setMediaMetadata(MediaMetadata.Builder()
                    .setTitle(item.title).setArtist(item.artist).setArtworkUri(artwork).build())
                .build()
        }
        c.setMediaItems(items, index, 0L)
        c.prepare()
        c.play()
    }
    val refresh: () -> Unit = {
        if (hasPermission) scope.launch {
            localSongs = runCatching { AudioLibrary.load(context) }.getOrDefault(emptyList())
        } else permissionLauncher.launch(permission)
    }

    if (showPlayer && activeSong != null) {
        FullPlayer(
            song = activeSong, playing = playing, position = progress, duration = length,
            isLiked = activeSong.id.toString() in likedIds,
            onLike = { toggleLike(activeSong.id) }, onClose = { showPlayer = false },
            onPlayPause = { if (playing) controller?.pause() else controller?.play() },
            onNext = { controller?.seekToNextMediaItem() },
            onPrevious = { controller?.seekToPreviousMediaItem() },
            onSeek = { controller?.seekTo(it) },
            shuffle = shuffleEnabled,
            repeatMode = repeatModeState,
            onShuffle = { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } },
            onRepeat = { controller?.let { it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            } } },
            onQueue = { showQueue = true },
            onLyrics = { showLyrics = true },
            onImportLyrics = {
                lyricSong = activeSong.id
                lyricPicker.launch(arrayOf("text/*", "application/octet-stream"))
            }
        )
    } else {
        Scaffold(
            containerColor = Base,
            bottomBar = {
                Column(Modifier.background(Brush.verticalGradient(listOf(Base.copy(alpha = 0.95f), Base)))) {
                    if (activeSong != null) {
                        MiniPlayer(activeSong, playing, progress, length,
                            onExpand = { showPlayer = true },
                            onPause = { if (playing) controller?.pause() else controller?.play() },
                            onNext = { controller?.seekToNextMediaItem() }
                        )
                    }
                    NavigationBar(containerColor = Base, tonalElevation = 0.dp) {
                        NavigationBarItem(selected = tab == Tab.HOME,
                            onClick = { tab = Tab.HOME }, icon = { Icon(Icons.Rounded.Home, null) },
                            label = { Text("首页", fontSize = 11.sp) })
                        NavigationBarItem(selected = tab == Tab.SEARCH,
                            onClick = { tab = Tab.SEARCH }, icon = { Icon(Icons.Rounded.Search, null) },
                            label = { Text("搜索", fontSize = 11.sp) })
                        NavigationBarItem(selected = tab == Tab.LIBRARY,
                            onClick = { tab = Tab.LIBRARY }, icon = { Icon(Icons.Rounded.LibraryMusic, null) },
                            label = { Text("音乐库", fontSize = 11.sp) })
                        NavigationBarItem(selected = false,
                            onClick = { showCreatePlaylist = true },
                            icon = { Icon(Icons.Rounded.AddCircleOutline, "新建歌单") },
                            label = { Text("创建", fontSize = 11.sp) })
                    }
                }
            }
        ) { pad ->
            Box(Modifier.fillMaxSize().padding(pad)) {
                when {
                    focusedPlaylistId != null -> {
                        val focused = playlists.find { it.id == focusedPlaylistId }
                        if (focused == null) {
                            LaunchedEffect(focusedPlaylistId) { focusedPlaylistId = null }
                        } else PlaylistDetails(
                            playlist = focused, songs = localSongs,
                            onBack = { focusedPlaylistId = null },
                            onPlay = ::playSong,
                            onRemove = { id -> playlists = store.removeSong(focused.id, id) },
                            onEdit = { editPlaylist = focused },
                            onDelete = {
                                playlists = store.deletePlaylist(focused.id)
                                focusedPlaylistId = null
                            }
                        )
                    }
                    tab == Tab.HOME -> HomePage(localSongs, likedIds, history = history,
                        playlists = playlists, onSearch = { tab = Tab.SEARCH },
                        onLibrary = { tab = Tab.LIBRARY }, onPlay = ::playSong,
                        onOpenPlaylist = { focusedPlaylistId = it }, onAbout = { showAbout = true })
                    tab == Tab.SEARCH -> SearchPage(localSongs, onPlay = ::playSong,
                        onlineStore = onlineStore, bookmarks = onlineBookmarks,
                        onToggleBookmark = ::toggleOnlineBookmark)
                    else -> LibraryPage(localSongs, likedIds, hasPermission, playlists,
                        onlineBookmarks = onlineBookmarks,
                        onToggleOnlineBookmark = ::toggleOnlineBookmark,
                        filter = libraryFilter, onFilter = { libraryFilter = it },
                        onCreate = { showCreatePlaylist = true },
                        onOpenPlaylist = { focusedPlaylistId = it },
                        onPermission = refresh, onPlay = ::playSong, onLike = ::toggleLike,
                        onAddToPlaylist = { addSongToPlaylist = it })
                }
                AnimatedVisibility(visible = playerError != null, modifier = Modifier.align(Alignment.TopCenter)) {
                    Surface(color = Color(0xFF58322E), shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().padding(16.dp).clickable { playerError = null }) {
                        Text(playerError.orEmpty() + "  · 点击关闭", modifier = Modifier.padding(14.dp), fontSize = 12.sp)
                    }
                }
            }
        }
    }
    if (showCreatePlaylist) {
        NamePlaylistDialog(title = "创建播放列表", initial = "", onDismiss = { showCreatePlaylist = false }) {
            playlists = store.createPlaylist(it)
            showCreatePlaylist = false
            focusedPlaylistId = playlists.lastOrNull()?.id
        }
    }
    editPlaylist?.let { playlist ->
        NamePlaylistDialog(title = "重命名播放列表", initial = playlist.name,
            onDismiss = { editPlaylist = null }) {
            playlists = store.renamePlaylist(playlist.id, it)
            editPlaylist = null
        }
    }
    addSongToPlaylist?.let { song ->
        AlertDialog(onDismissRequest = { addSongToPlaylist = null },
            title = { Text("添加到播放列表") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(song.title, style = MaterialTheme.typography.bodyMedium)
                    if (playlists.isEmpty()) Text("先在音乐库创建一个播放列表。", color = Muted)
                    playlists.forEach { playlist ->
                        TextButton(onClick = {
                            playlists = store.addSong(playlist.id, song.id)
                            addSongToPlaylist = null
                        }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Rounded.PlaylistAdd, null)
                            Spacer(Modifier.width(10.dp))
                            Text(playlist.name, modifier = Modifier.weight(1f), maxLines = 1)
                        }
                    }
                }
            }, confirmButton = {
                TextButton(onClick = { addSongToPlaylist = null; showCreatePlaylist = true }) {
                    Text("新建列表")
                }
            }, dismissButton = { TextButton(onClick = { addSongToPlaylist = null }) { Text("取消") } })
    }
    if (showQueue) {
        val queued = (0 until (controller?.mediaItemCount ?: 0)).mapNotNull { index ->
            val item = controller?.getMediaItemAt(index)
            val song = localSongs.firstOrNull { it.id.toString() == item?.mediaId }
            if (song == null) null else index to song
        }
        AlertDialog(onDismissRequest = { showQueue = false },
            title = { Text("接下来播放 · ${queued.size} 首") },
            text = { LazyColumn(modifier = Modifier.heightIn(max = 410.dp)) {
                items(queued, key = { it.first }) { (index, song) ->
                    Row(Modifier.fillMaxWidth().clickable { controller?.seekToDefaultPosition(index); showQueue = false }
                        .padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (index == controller?.currentMediaItemIndex) "♫" else "${index + 1}",
                            color = Accent, modifier = Modifier.width(32.dp))
                        Column(Modifier.weight(1f)) {
                            Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(song.artist, color = Muted, fontSize = 11.sp)
                        }
                    }
                }
            } },
            confirmButton = { TextButton(onClick = { showQueue = false }) { Text("关闭") } })
    }
    if (showLyrics) activeSong?.let { song ->
        LyricDialog(song = song, position = progress, raw = store.lyric(song.id),
            onDismiss = { showLyrics = false },
            onImport = {
                lyricSong = song.id
                lyricPicker.launch(arrayOf("text/*", "application/octet-stream"))
            })
    }
    if (showAbout) {
        AlertDialog(onDismissRequest = { showAbout = false },
            title = { Text("QQMusic · 第三方实验版") },
            text = { Text("独立学习项目，与 QQ 音乐及 Spotify 官方无关联。支持本地歌曲播放、个人歌单、QQ 曲库公开信息搜索、本机收藏与歌词预览。未得到 QQ 音乐账号/会员在线播放授权，无法直接播放其受保护音频。应用图标使用了 QQ 音乐标识，仅作个人演示，不代表获得商标许可。") },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("知道了") } })
    }
}

@Composable
private fun HomePage(
    songs: List<LocalSong>, liked: Set<String>, history: List<Long>,
    playlists: List<UserPlaylist>, onSearch: () -> Unit, onLibrary: () -> Unit,
    onPlay: (LocalSong, List<LocalSong>) -> Unit, onOpenPlaylist: (String) -> Unit,
    onAbout: () -> Unit
) {
    val recent = remember(songs, history) { history.mapNotNull { id -> songs.find { it.id == id } } }
    val favorites = remember(songs, liked) { songs.filter { it.id.toString() in liked } }
    var category by remember { mutableStateOf(0) }
    LazyColumn(contentPadding = PaddingValues(bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(23.dp)) {
        item {
            Column(Modifier.background(Brush.verticalGradient(listOf(Color(0xFF1C3327), Base)))
                .padding(start = 18.dp, end = 18.dp, top = 15.dp, bottom = 2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(CircleShape).background(Accent), contentAlignment = Alignment.Center) {
                        Text("Q", fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, color = Base)
                    }
                    Spacer(Modifier.width(10.dp))
                    listOf("全部", "音乐", "播放列表").forEachIndexed { index, title ->
                        Spacer(Modifier.width(5.dp))
                        FilterPill(title, category == index) { category = index }
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = onAbout, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Rounded.Settings, "设置与说明", tint = Bright)
                    }
                }
            }
        }
        if (category != 2) {
            item {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    Text("回到你的音乐", fontWeight = FontWeight.Bold, fontSize = 24.sp, color = Bright)
                    Spacer(Modifier.height(15.dp))
                    val items = (recent + favorites + songs).distinctBy { it.id }.take(8)
                    if (items.isEmpty()) {
                        EmptyQueue(onLibrary)
                    } else {
                        items.chunked(2).forEach { pair ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                pair.forEach { song ->
                                    Row(Modifier.weight(1f).height(59.dp).clip(RoundedCornerShape(6.dp))
                                        .background(Elevated).clickable { onPlay(song, songs) },
                                        verticalAlignment = Alignment.CenterVertically) {
                                        Artwork(song, Modifier.size(59.dp), song.id.toInt(), radius = 4.dp)
                                        Text(song.title, color = Bright, fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold, maxLines = 2,
                                            modifier = Modifier.padding(horizontal = 8.dp))
                                    }
                                }
                                if (pair.size < 2) Spacer(Modifier.weight(1f))
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
            }
            item {
                HeaderRow("最近播放", "全部音乐", onLibrary)
                if (recent.isEmpty()) {
                    Text("播放一首本地歌曲，就会出现在这里", color = Muted,
                        modifier = Modifier.padding(horizontal = 20.dp), fontSize = 13.sp)
                } else {
                    LazyRow(contentPadding = PaddingValues(horizontal = 18.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(recent.take(12), key = { it.id }) { song ->
                            AlbumTile(song, Modifier.width(148.dp), { onPlay(song, recent) })
                        }
                    }
                }
            }
            item {
                HeaderRow("为你播放", "音乐库", onLibrary)
                LazyRow(contentPadding = PaddingValues(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(songs.take(18), key = { it.id }) { song ->
                        AlbumTile(song, Modifier.width(148.dp), { onPlay(song, songs) })
                    }
                }
            }
            item {
                HeaderRow("你喜欢的歌", "查看收藏", onLibrary)
                if (favorites.isEmpty()) EmptyQueue(onLibrary)
                else Column(Modifier.padding(horizontal = 18.dp)) {
                    favorites.take(4).forEachIndexed { i, song ->
                        SongLine(song, i, true, { onPlay(song, favorites) }, null)
                    }
                }
            }
        }
        if (category != 1) {
            item {
                HeaderRow("你的播放列表", "打开音乐库", onLibrary)
                if (playlists.isEmpty()) EmptyQueue(onLibrary)
                else LazyRow(contentPadding = PaddingValues(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(playlists, key = { it.id }) { playlist ->
                        PlaylistTile(playlist, onClick = { onOpenPlaylist(playlist.id) })
                    }
                }
            }
        }
        item {
            Column(Modifier.padding(horizontal = 18.dp)) {
                Text("QQ 音乐曲库", color = Bright, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                    .background(Panel).clickable { onSearch() }.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Search, null, tint = Accent)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("搜索 QQ 音乐", color = Bright, fontWeight = FontWeight.SemiBold)
                        Text("公开歌曲信息 · 官方应用播放", color = Muted, fontSize = 11.sp)
                    }
                    Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
                }
            }
        }
    }
}

@Composable
private fun AlbumTile(song: LocalSong, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick)) {
        Artwork(song, Modifier.fillMaxWidth().aspectRatio(1f), song.id.toInt(), radius = 6.dp)
        Spacer(Modifier.height(9.dp))
        Text(song.title, color = Bright, fontWeight = FontWeight.Bold, fontSize = 13.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(song.artist, color = Muted, fontSize = 11.sp, maxLines = 1,
            overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun PlaylistTile(playlist: UserPlaylist, onClick: () -> Unit) {
    Column(Modifier.width(148.dp).clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(6.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF343C99), Color(0xFF19124B)))),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.QueueMusic, null, tint = Bright, modifier = Modifier.size(64.dp))
        }
        Spacer(Modifier.height(9.dp))
        Text(playlist.name, color = Bright, fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("播放列表 · ${playlist.songIds.size} 首", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun SearchPage(
    local: List<LocalSong>, onPlay: (LocalSong, List<LocalSong>) -> Unit,
    onlineStore: OnlineLibraryStore, bookmarks: List<QqSong>,
    onToggleBookmark: (QqSong) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf(SearchMode.QQ) }
    var group by remember { mutableStateOf(QqGroup.SONGS) }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<QqSong>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var searchVersion by remember { mutableIntStateOf(0) }
    var page by remember { mutableIntStateOf(0) }
    var submittedQuery by remember { mutableStateOf("") }
    var hasMore by remember { mutableStateOf(false) }
    var searchHistory by remember { mutableStateOf(onlineStore.searches()) }
    var albumFilter by remember { mutableStateOf<String?>(null) }
    var artistFilter by remember { mutableStateOf<String?>(null) }
    var lyricTrack by remember { mutableStateOf<QqSong?>(null) }
    var lyricResult by remember { mutableStateOf<Result<String>?>(null) }

    fun openOfficial(song: QqSong) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(song.url))
        runCatching { context.startActivity(intent) }
            .onFailure { error = "未找到可以打开 QQ 音乐链接的应用" }
    }
    fun share(song: QqSong) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "${song.title} - ${song.artist}\n${song.url}")
        }
        runCatching { context.startActivity(Intent.createChooser(intent, "分享歌曲")) }
            .onFailure { error = "当前设备无法分享" }
    }
    fun runSearch(nextPage: Int = 1, term: String = query) {
        if (busy) return
        val keyword = (if (nextPage > 1) submittedQuery else term).trim()
        if (keyword.isBlank()) { error = "请输入歌曲或歌手"; return }
        if (nextPage == 1) {
            submittedQuery = keyword
            query = keyword
            albumFilter = null
            artistFilter = null
            results = emptyList()
            page = 0
            hasMore = false
            searchHistory = onlineStore.recordSearch(keyword)
        }
        val requestId = ++searchVersion
        busy = true
        error = null
        scope.launch {
            val outcome = QqMusicCatalog.search(keyword, nextPage)
            if (requestId != searchVersion) return@launch
            busy = false
            outcome.onSuccess { batch ->
                results = (if (nextPage == 1) batch else results + batch).distinctBy { it.mid }
                page = nextPage
                hasMore = batch.size >= 30 && nextPage < 50
            }.onFailure {
                error = "QQ 音乐公开搜索不可用：${it.message ?: "网络错误"}"
            }
        }
    }
    LaunchedEffect(lyricTrack?.mid) {
        lyricResult = null
        lyricTrack?.let { lyricResult = QqMusicCatalog.lyrics(it.mid) }
    }
    val shownSongs = remember(results, albumFilter, artistFilter) {
        results.filter { (albumFilter == null || it.albumMid == albumFilter) &&
            (artistFilter == null || it.artist == artistFilter) }
    }
    val albums = remember(results) { results.filter { it.albumMid.isNotBlank() }.distinctBy { it.albumMid } }
    val artists = remember(results) { results.distinctBy { it.artist } }

    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(18.dp))
        Text("搜索", fontSize = 32.sp, color = Bright, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            FilterPill("QQ 音乐", mode == SearchMode.QQ) { mode = SearchMode.QQ }
            FilterPill("本地音乐", mode == SearchMode.LOCAL) { mode = SearchMode.LOCAL }
        }
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it.take(100) },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Accent) },
            placeholder = { Text("歌曲、歌手、专辑") },
            trailingIcon = { if (mode == SearchMode.QQ) IconButton(onClick = { runSearch() }, enabled = !busy) {
                Icon(Icons.Rounded.ArrowForward, "搜索")
            } },
            shape = RoundedCornerShape(16.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { if (mode == SearchMode.QQ) runSearch() })
        )
        Spacer(Modifier.height(14.dp))
        if (mode == SearchMode.QQ) {
            Text("公开曲目信息 · 可收藏、预览歌词或匹配本地播放", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                FilterPill("歌曲", group == QqGroup.SONGS) { group = QqGroup.SONGS; albumFilter = null; artistFilter = null }
                FilterPill("专辑", group == QqGroup.ALBUMS) { group = QqGroup.ALBUMS }
                FilterPill("歌手", group == QqGroup.ARTISTS) { group = QqGroup.ARTISTS }
            }
            Spacer(Modifier.height(12.dp))
            if (busy && page == 0) LinearProgressIndicator(Modifier.fillMaxWidth())
            error?.let { Text(it, color = Color(0xFFFFAFA0), fontSize = 13.sp) }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 26.dp)) {
                if (results.isEmpty() && !busy) {
                    if (searchHistory.isNotEmpty()) {
                        item {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("最近搜索", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                TextButton(onClick = { onlineStore.clearSearches(); searchHistory = emptyList() }) { Text("清除") }
                            }
                            searchHistory.take(6).forEach { term ->
                                Row(Modifier.fillMaxWidth().clickable { runSearch(1, term) }
                                    .padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.History, null, tint = Muted, modifier = Modifier.size(20.dp))
                                    Spacer(Modifier.width(11.dp))
                                    Text(term, color = Bright)
                                }
                            }
                        }
                    }
                    item {
                        Text("随心探索", color = Bright, fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(vertical = 9.dp))
                        val genres = listOf("流行", "华语", "摇滚", "说唱", "民谣", "古典", "电子", "轻音乐")
                        genres.chunked(2).forEach { pair ->
                            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                pair.forEach { term ->
                                    Box(Modifier.weight(1f).height(74.dp).clip(RoundedCornerShape(12.dp))
                                        .background(gradientPalette[Math.floorMod(term.hashCode(), gradientPalette.size)][0])
                                        .clickable { runSearch(1, term) }.padding(15.dp)) {
                                        Text(term, color = Bright, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
                if (results.isNotEmpty()) {
                    when (group) {
                        QqGroup.SONGS -> {
                            if (albumFilter != null || artistFilter != null) item {
                                Text("仅显示本次搜索结果中的分类歌曲 · 点击返回全部",
                                    color = Accent, modifier = Modifier.clickable {
                                        albumFilter = null; artistFilter = null
                                    }.padding(vertical = 8.dp), fontSize = 12.sp)
                            }
                            items(shownSongs, key = { it.mid }) { song ->
                                val match = LocalSongMatcher.match(song.title, song.artist, local)
                                QqTrackRow(song, bookmarked = bookmarks.any { it.mid == song.mid },
                                    onOpen = { openOfficial(song) },
                                    onBookmark = { onToggleBookmark(song) },
                                    onLyric = { lyricTrack = song },
                                    onShare = { share(song) },
                                    onPlayLocal = match?.let { found -> ({ onPlay(found, local) }) })
                            }
                        }
                        QqGroup.ALBUMS -> {
                            item { Text("从当前歌曲结果聚合的专辑（非全站专辑搜索）", color = Muted, fontSize = 12.sp) }
                            items(albums, key = { it.albumMid }) { album ->
                                Row(Modifier.fillMaxWidth().clickable {
                                    albumFilter = album.albumMid; artistFilter = null; group = QqGroup.SONGS
                                }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Artwork(cover = album.cover, seed = album.mid.hashCode(),
                                        modifier = Modifier.size(68.dp))
                                    Spacer(Modifier.width(14.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(album.albumName.ifBlank { album.title }, fontWeight = FontWeight.Bold, maxLines = 1)
                                        Text(album.artist, color = Muted, fontSize = 12.sp)
                                    }
                                    Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
                                }
                            }
                        }
                        QqGroup.ARTISTS -> {
                            item { Text("从当前歌曲结果聚合的歌手（非全站歌手搜索）", color = Muted, fontSize = 12.sp) }
                            items(artists, key = { it.artist }) { artist ->
                                Row(Modifier.fillMaxWidth().clickable {
                                    artistFilter = artist.artist; albumFilter = null; group = QqGroup.SONGS
                                }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(50.dp).clip(CircleShape).background(Elevated),
                                        contentAlignment = Alignment.Center) {
                                        Icon(Icons.Rounded.Person, null, tint = Accent)
                                    }
                                    Spacer(Modifier.width(14.dp))
                                    Text(artist.artist, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
                                }
                            }
                        }
                    }
                    if (hasMore) item {
                        TextButton(onClick = { runSearch(page + 1) }, enabled = !busy,
                            modifier = Modifier.fillMaxWidth()) {
                            if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                            else Text("加载更多公开结果")
                        }
                    }
                }
            }
        } else {
            val matched = remember(local, query) {
                if (query.isBlank()) local else local.filter {
                    it.title.contains(query, true) || it.artist.contains(query, true)
                }
            }
            Text("找到 ${matched.size} 首本地歌曲", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(15.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(matched, key = { it.id }) { song ->
                    SongLine(song, song.id.toInt(), liked = false,
                        onClick = { onPlay(song, matched) }, onHeart = null)
                }
            }
        }
    }
    lyricTrack?.let { song ->
        AlertDialog(onDismissRequest = { lyricTrack = null },
            title = { Text("${song.title} · 在线歌词") },
            text = { Box(Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState())) {
                val result = lyricResult
                when {
                    result == null -> CircularProgressIndicator()
                    result.isSuccess -> Text(result.getOrNull().orEmpty(), fontSize = 14.sp, lineHeight = 24.sp)
                    else -> Text("无法读取公开歌词：${result.exceptionOrNull()?.message ?: "未知错误"}", color = Muted)
                }
            } },
            confirmButton = { TextButton(onClick = { lyricTrack = null }) { Text("关闭") } },
            dismissButton = { TextButton(onClick = { openOfficial(song) }) { Text("官方查看") } })
    }
}

@Composable
private fun QqTrackRow(song: QqSong, bookmarked: Boolean,
    onOpen: () -> Unit, onBookmark: () -> Unit, onLyric: () -> Unit,
    onShare: () -> Unit, onPlayLocal: (() -> Unit)? = null
) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onOpen).padding(vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Artwork(cover = song.cover, seed = song.mid.hashCode(), modifier = Modifier.size(55.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, color = Bright, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song.artist, color = Muted, fontSize = 12.sp, maxLines = 1)
                if (onPlayLocal != null) Text("已匹配本地文件 · 可播放", color = Accent, fontSize = 10.sp)
            }
            IconButton(onClick = onBookmark, modifier = Modifier.size(36.dp)) {
                Icon(if (bookmarked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    "本机收藏", tint = if (bookmarked) Accent else Muted, modifier = Modifier.size(20.dp))
            }
            if (onPlayLocal != null) IconButton(onClick = onPlayLocal, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Rounded.PlayCircleFilled, "播放本地匹配歌曲", tint = Accent)
            }
            IconButton(onClick = onOpen, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Rounded.OpenInNew, "QQ 音乐打开", tint = Muted, modifier = Modifier.size(20.dp))
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Text("歌词", color = Muted, modifier = Modifier.clickable(onClick = onLyric)
                .padding(horizontal = 12.dp, vertical = 5.dp), fontSize = 11.sp)
            Text("分享", color = Muted, modifier = Modifier.clickable(onClick = onShare)
                .padding(horizontal = 12.dp, vertical = 5.dp), fontSize = 11.sp)
        }
    }
}

@Composable
private fun LibraryPage(
    songs: List<LocalSong>, liked: Set<String>, permission: Boolean,
    playlists: List<UserPlaylist>, onlineBookmarks: List<QqSong>,
    onToggleOnlineBookmark: (QqSong) -> Unit, filter: LibraryFilter,
    onFilter: (LibraryFilter) -> Unit, onCreate: () -> Unit,
    onOpenPlaylist: (String) -> Unit, onPermission: () -> Unit,
    onPlay: (LocalSong, List<LocalSong>) -> Unit,
    onLike: (Long) -> Unit, onAddToPlaylist: (LocalSong) -> Unit
) {
    val visible = remember(songs, liked, filter) {
        if (filter == LibraryFilter.LIKED) songs.filter { it.id.toString() in liked } else songs
    }
    var savedLyricTrack by remember { mutableStateOf<QqSong?>(null) }
    var savedLyricResult by remember { mutableStateOf<Result<String>?>(null) }
    LaunchedEffect(savedLyricTrack?.mid) {
        savedLyricResult = null
        savedLyricTrack?.let { savedLyricResult = QqMusicCatalog.lyrics(it.mid) }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(CircleShape).background(Accent), contentAlignment = Alignment.Center) {
                Text("Q", fontWeight = FontWeight.Bold, color = Base)
            }
            Spacer(Modifier.width(10.dp))
            Text("你的音乐库", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold,
                color = Bright, modifier = Modifier.weight(1f))
            IconButton(onClick = onPermission) { Icon(Icons.Rounded.Refresh, "扫描本地音乐", tint = Bright) }
            IconButton(onClick = onCreate) { Icon(Icons.Rounded.Add, "创建播放列表", tint = Bright) }
        }
        Spacer(Modifier.height(18.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterPill("所有歌曲", filter == LibraryFilter.ALL) { onFilter(LibraryFilter.ALL) } }
            item { FilterPill("我喜欢的", filter == LibraryFilter.LIKED) { onFilter(LibraryFilter.LIKED) } }
            item { FilterPill("播放列表", filter == LibraryFilter.PLAYLISTS) { onFilter(LibraryFilter.PLAYLISTS) } }
            item { FilterPill("QQ 曲目收藏", filter == LibraryFilter.QQ_SAVED) { onFilter(LibraryFilter.QQ_SAVED) } }
        }
        Spacer(Modifier.height(20.dp))
        if (filter == LibraryFilter.QQ_SAVED) {
            Text("本机收藏 · 不与 QQ 音乐账号同步", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            if (onlineBookmarks.isEmpty()) {
                Text("还没有收藏的 QQ 曲目。在搜索页点击爱心即可保存。",
                    color = Muted, modifier = Modifier.padding(top = 25.dp))
            } else {
                val ctx = LocalContext.current
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(onlineBookmarks, key = { it.mid }) { song ->
                        val match = LocalSongMatcher.match(song.title, song.artist, songs)
                        QqTrackRow(song, bookmarked = true,
                            onOpen = { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(song.url))) } },
                            onBookmark = { onToggleOnlineBookmark(song) },
                            onLyric = { savedLyricTrack = song },
                            onShare = {
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"; putExtra(Intent.EXTRA_TEXT, song.url)
                                }
                                runCatching { ctx.startActivity(Intent.createChooser(intent, "分享歌曲")) }
                            },
                            onPlayLocal = match?.let { found -> ({ onPlay(found, songs) }) })
                    }
                }
            }
        } else if (filter == LibraryFilter.PLAYLISTS) {
            if (playlists.isEmpty()) {
                EmptyInfo("创建你的第一个播放列表", "把喜爱的本地歌曲收藏在一个地方。",
                    "创建播放列表", onCreate)
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(playlists, key = { it.id }) { playlist ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                            .clickable { onOpenPlaylist(playlist.id) },
                            verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(62.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFF373A77)),
                                contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.QueueMusic, null, tint = Bright)
                            }
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(playlist.name, color = Bright, fontWeight = FontWeight.SemiBold)
                                Text("播放列表 · ${playlist.songIds.size} 首", color = Muted, fontSize = 12.sp)
                            }
                            Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
                        }
                    }
                }
            }
        } else if (!permission) {
            EmptyInfo("让音乐在这里相遇", "授权读取设备音频后可创建收藏和播放列表。",
                "允许访问音乐", onPermission)
        } else if (visible.isEmpty()) {
            EmptyInfo(if (filter == LibraryFilter.LIKED) "还没有喜欢的歌曲" else "暂无本地歌曲",
                "播放 MP3、FLAC 等本地文件。需要时点击刷新。",
                if (filter == LibraryFilter.LIKED) "所有歌曲" else "重新扫描",
                if (filter == LibraryFilter.LIKED) ({ onFilter(LibraryFilter.ALL) }) else onPermission)
        } else {
            Text("${visible.size} 首歌曲 · 长期保存在设备", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 20.dp)) {
                items(visible, key = { it.id }) { song ->
                    SongLine(song, song.id.toInt(), liked = song.id.toString() in liked,
                        onClick = { onPlay(song, visible) }, onHeart = { onLike(song.id) },
                        onMenu = { onAddToPlaylist(song) })
                }
            }
        }
    }
    savedLyricTrack?.let { song ->
        AlertDialog(onDismissRequest = { savedLyricTrack = null },
            title = { Text("${song.title} · 在线歌词") },
            text = { Box(Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState())) {
                val result = savedLyricResult
                when {
                    result == null -> CircularProgressIndicator()
                    result.isSuccess -> Text(result.getOrNull().orEmpty(), fontSize = 14.sp, lineHeight = 24.sp)
                    else -> Text("无法读取公开歌词：${result.exceptionOrNull()?.message ?: "未知错误"}", color = Muted)
                }
            } },
            confirmButton = { TextButton(onClick = { savedLyricTrack = null }) { Text("关闭") } })
    }
}

@Composable
private fun PlaylistDetails(
    playlist: UserPlaylist, songs: List<LocalSong>, onBack: () -> Unit,
    onPlay: (LocalSong, List<LocalSong>) -> Unit, onRemove: (Long) -> Unit,
    onEdit: () -> Unit, onDelete: () -> Unit
) {
    val list = remember(playlist, songs) {
        playlist.songIds.mapNotNull { id -> songs.find { it.id == id } }
    }
    var showDelete by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "返回", tint = Bright) }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onEdit) { Icon(Icons.Rounded.Edit, "重命名", tint = Bright) }
            IconButton(onClick = { showDelete = true }) {
                Icon(Icons.Rounded.DeleteOutline, "删除歌单", tint = Muted)
            }
        }
        LazyColumn(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp)) {
            item {
                Box(Modifier.fillMaxWidth().height(210.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(205.dp).clip(RoundedCornerShape(5.dp)).background(
                        Brush.linearGradient(listOf(Color(0xFF4E478F), Color(0xFF1E1447)))),
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.QueueMusic, null, tint = Bright, modifier = Modifier.size(90.dp))
                    }
                }
                Spacer(Modifier.height(15.dp))
                Text(playlist.name, color = Bright, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("私人播放列表 · ${list.size} 首本地音乐", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(20.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${list.size} 首", color = Muted, modifier = Modifier.weight(1f))
                    IconButton(onClick = {
                        if (list.isNotEmpty()) onPlay(list.random(), list)
                    }, enabled = list.isNotEmpty()) { Icon(Icons.Rounded.Shuffle, "随机", tint = Accent) }
                    Box(Modifier.size(54.dp).clip(CircleShape)
                        .background(if (list.isEmpty()) Muted else Accent)
                        .clickable(enabled = list.isNotEmpty()) { list.firstOrNull()?.let { onPlay(it, list) } },
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.PlayArrow, null, tint = Base, modifier = Modifier.size(32.dp))
                    }
                }
            }
            if (list.isEmpty()) item {
                Text("播放列表是空的。回到音乐库，点击歌曲右侧更多按钮加入。",
                    color = Muted, fontSize = 14.sp)
            }
            items(list, key = { it.id }) { song ->
                SongLine(song, song.id.toInt(), false, { onPlay(song, list) },
                    onHeart = null, onMenu = { onRemove(song.id) })
            }
        }
    }
    if (showDelete) AlertDialog(onDismissRequest = { showDelete = false },
        title = { Text("删除播放列表？") },
        text = { Text("仅删除本地播放列表，不会删除音频文件。") },
        confirmButton = { TextButton(onClick = { showDelete = false; onDelete() }) { Text("删除") } },
        dismissButton = { TextButton(onClick = { showDelete = false }) { Text("取消") } })
}

@Composable
private fun NamePlaylistDialog(title: String, initial: String, onDismiss: () -> Unit,
    onSubmit: (String) -> Unit
) {
    var name by remember(initial) { mutableStateOf(initial) }
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = name, onValueChange = { name = it.take(80) },
            label = { Text("名称") }, maxLines = 1, singleLine = true) },
        confirmButton = { TextButton(onClick = { onSubmit(name.trim()) }, enabled = name.isNotBlank()) {
            Text("保存")
        } }, dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } })
}

@Composable
private fun LyricDialog(song: LocalSong, position: Long, raw: String,
    onDismiss: () -> Unit, onImport: () -> Unit
) {
    val lyrics = remember(raw) { LyricParser.parse(raw) }
    val active = lyrics.indexOfLast { it.atMs <= position }.coerceAtLeast(0)
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text("${song.title} · 歌词") },
        text = {
            if (lyrics.isEmpty()) {
                Text("尚未导入歌词。可为这首本地歌曲选择一份 LRC 文件。", color = Muted)
            } else LazyColumn(modifier = Modifier.heightIn(max = 420.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(lyrics.size) { index ->
                    Text(lyrics[index].content, color = if (index == active) Accent else Muted,
                        fontSize = if (index == active) 19.sp else 15.sp,
                        fontWeight = if (index == active) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.fillMaxWidth())
                }
            }
        },
        confirmButton = { TextButton(onClick = onImport) { Text("导入歌词") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("关闭") } })
}

@Composable
private fun MiniPlayer(
    song: LocalSong, playing: Boolean, position: Long, duration: Long,
    onExpand: () -> Unit, onPause: () -> Unit, onNext: () -> Unit
) {
    Column(Modifier.padding(horizontal = 8.dp).padding(bottom = 3.dp)
        .shadow(7.dp, RoundedCornerShape(14.dp))
        .clip(RoundedCornerShape(14.dp)).background(Color(0xFF2E493C))) {
        Row(Modifier.fillMaxWidth().height(65.dp).clickable(onClick = onExpand).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Artwork(song, modifier = Modifier.size(48.dp), seed = song.id.toInt())
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, color = Bright, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song.artist, color = Color(0xFFC7D1CA), fontSize = 11.sp, maxLines = 1)
            }
            IconButton(onClick = onPause) {
                Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    "播放或暂停", tint = Bright, modifier = Modifier.size(27.dp))
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Rounded.SkipNext, "下一首", tint = Bright)
            }
        }
        LinearProgressIndicator(progress = { if (duration <= 0) 0f else
            (position.toFloat() / duration.toFloat()).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(2.dp), color = Accent,
            trackColor = Color(0xFF547361))
    }
}

@Composable
private fun FullPlayer(
    song: LocalSong, playing: Boolean, position: Long, duration: Long,
    isLiked: Boolean, onLike: () -> Unit, onClose: () -> Unit,
    onPlayPause: () -> Unit, onNext: () -> Unit, onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    shuffle: Boolean, repeatMode: Int, onShuffle: () -> Unit,
    onRepeat: () -> Unit, onQueue: () -> Unit, onLyrics: () -> Unit,
    onImportLyrics: () -> Unit
) {
    val gradient = gradientPalette[(song.id % gradientPalette.size).toInt().coerceAtLeast(0)]
    var scrubbing by remember(song.id) { mutableStateOf<Float?>(null) }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(
        listOf(gradient[0].copy(alpha = 0.95f), Color(0xFF171F1B), Base)
    )).padding(horizontal = 26.dp)) {
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "收起播放页", tint = Bright,
                modifier = Modifier.size(33.dp)) }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("正在播放", color = Muted, fontSize = 11.sp)
                Text("本地音乐", color = Bright, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Icon(Icons.Rounded.MoreHoriz, null, tint = Bright)
        }
        Spacer(Modifier.weight(0.6f))
        Artwork(song, modifier = Modifier.fillMaxWidth().aspectRatio(1f)
            .shadow(24.dp, RoundedCornerShape(12.dp)), seed = song.id.toInt(), radius = 12.dp)
        Spacer(Modifier.weight(0.7f))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(song.title, color = Bright, fontSize = 23.sp, fontWeight = FontWeight.Bold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Text(song.artist, color = Color(0xFFCAD2CB), fontSize = 15.sp)
            }
            IconButton(onClick = onLike) { Icon(
                if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                "喜欢", tint = if (isLiked) Accent else Bright
            ) }
        }
        Spacer(Modifier.height(20.dp))
        Slider(value = scrubbing ?: if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f,
            onValueChange = { scrubbing = it },
            onValueChangeFinished = {
                scrubbing?.let { onSeek((it * duration).toLong()) }
                scrubbing = null
            }, colors = SliderDefaults.colors(thumbColor = Bright, activeTrackColor = Bright,
                inactiveTrackColor = Color(0xFF63756A)), modifier = Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(timeText(position), color = Muted, fontSize = 11.sp)
            Text(timeText(duration), color = Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.height(15.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onShuffle) {
                Icon(Icons.Rounded.Shuffle, "随机播放", tint = if (shuffle) Accent else Muted,
                    modifier = Modifier.size(23.dp))
            }
            IconButton(onClick = onPrevious, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Rounded.SkipPrevious, "上一首", tint = Bright, modifier = Modifier.size(32.dp))
            }
            Box(Modifier.size(71.dp).clip(CircleShape).background(Accent).clickable(onClick = onPlayPause),
                contentAlignment = Alignment.Center) {
                Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    "播放或暂停", tint = Base, modifier = Modifier.size(39.dp))
            }
            IconButton(onClick = onNext, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Rounded.SkipNext, "下一首", tint = Bright, modifier = Modifier.size(32.dp))
            }
            IconButton(onClick = onRepeat) {
                Icon(if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    "循环模式", tint = if (repeatMode == Player.REPEAT_MODE_OFF) Muted else Accent,
                    modifier = Modifier.size(23.dp))
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton(onClick = onLyrics) { Icon(Icons.Rounded.Subtitles, "歌词", tint = Bright) }
            TextButton(onClick = onImportLyrics) { Text("导入 LRC", color = Muted, fontSize = 12.sp) }
            IconButton(onClick = onQueue) { Icon(Icons.Rounded.QueueMusic, "播放队列", tint = Bright) }
        }
        Spacer(Modifier.weight(0.5f))
    }
}

@Composable
private fun Artwork(song: LocalSong, modifier: Modifier, seed: Int, radius: androidx.compose.ui.unit.Dp = 12.dp) {
    val artUri = remember(song.albumId) {
        if (song.albumId > 0) ContentUris.withAppendedId(
            Uri.parse("content://media/external/audio/albumart"), song.albumId
        ) else null
    }
    Artwork(cover = artUri, seed = seed, modifier = modifier, radius = radius)
}

@Composable
private fun Artwork(cover: Any?, seed: Int, modifier: Modifier, radius: androidx.compose.ui.unit.Dp = 12.dp) {
    val colors = gradientPalette[(seed.toLong().absoluteValue % gradientPalette.size).toInt()]
    Box(modifier.clip(RoundedCornerShape(radius)).background(Brush.linearGradient(colors)),
        contentAlignment = Alignment.Center) {
        if (cover == null) {
            Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(alpha = 0.78f),
                modifier = Modifier.fillMaxSize(0.38f))
        } else {
            SubcomposeAsyncImage(model = cover, contentDescription = null,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(),
                loading = { Icon(Icons.Rounded.MusicNote, null, tint = Bright.copy(alpha = 0.7f)) },
                error = { Icon(Icons.Rounded.MusicNote, null, tint = Bright.copy(alpha = 0.7f)) })
        }
    }
}

@Composable
private fun HeaderRow(title: String, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Bright, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text(action, color = Muted, fontSize = 12.sp, modifier = Modifier.clickable(onClick = onClick))
    }
    Spacer(Modifier.height(13.dp))
}

@Composable
private fun SongLine(song: LocalSong, index: Int, liked: Boolean,
                     onClick: () -> Unit, onHeart: (() -> Unit)?,
                     onMenu: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).clickable(onClick = onClick)
        .padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Artwork(song, Modifier.size(55.dp), index)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, color = Bright, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(song.artist, color = Muted, fontSize = 12.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis)
        }
        if (onHeart != null) IconButton(onClick = onHeart) {
            Icon(if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                "喜欢", tint = if (liked) Accent else Muted, modifier = Modifier.size(20.dp))
        } else if (onMenu == null) Icon(Icons.Rounded.PlayArrow, null, tint = Muted,
            modifier = Modifier.size(22.dp))
        if (onMenu != null) IconButton(onClick = onMenu) {
            Icon(Icons.Rounded.MoreVert, "管理歌曲", tint = Muted,
                modifier = Modifier.size(22.dp))
        }
    }
}

@Composable
private fun FilterPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(Modifier.clip(CircleShape).background(if (selected) Accent else Elevated)
        .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 9.dp)) {
        Text(text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
            color = if (selected) Base else Bright)
    }
}

@Composable
private fun EmptyQueue(onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp)
        .clip(RoundedCornerShape(18.dp)).background(Panel).clickable(onClick = onClick)
        .padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(60.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF2B473B)),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.QueueMusic, null, tint = Accent, modifier = Modifier.size(32.dp))
        }
        Spacer(Modifier.width(15.dp))
        Column(Modifier.weight(1f)) {
            Text("打造你的私人歌单", color = Bright, fontWeight = FontWeight.Bold)
            Text("导入本地音乐，随时开启播放", color = Muted, fontSize = 12.sp)
        }
        Icon(Icons.Rounded.ArrowForward, null, tint = Muted)
    }
}

@Composable
private fun EmptyInfo(title: String, body: String, button: String, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 55.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(110.dp).clip(CircleShape).background(Panel), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.LibraryMusic, null, tint = Accent, modifier = Modifier.size(53.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text(title, color = Bright, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.height(8.dp))
        Text(body, color = Muted, textAlign = TextAlign.Center, fontSize = 13.sp, lineHeight = 20.sp)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Base)) {
            Text(button, fontWeight = FontWeight.SemiBold)
        }
    }
}

private fun timeText(ms: Long): String {
    val total = ms.coerceAtLeast(0L) / 1000L
    return "%d:%02d".format(total / 60, total % 60)
}
