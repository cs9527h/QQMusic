package com.shuocao.qqmusic

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.CancellationException
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * QQ public metadata adapter. Endpoints are unofficial, may change without notice and
 * do not establish streaming, login, member or downloads permissions.
 * No credential, cookie, reverse-engineered signature or DRM bypass is included.
 */
object QqMusicCatalog {
    private const val PAGE_SIZE = 30

    suspend fun search(keywords: String, page: Int = 1): Result<List<QqSong>> = withContext(Dispatchers.IO) {
        networkResult {
            require(keywords.isNotBlank()) { "请输入搜索关键词" }
            require(keywords.length <= 100) { "关键词过长" }
            require(page in 1..50) { "页码不正确" }
            val keyword = URLEncoder.encode(keywords.trim(), "UTF-8")
            val endpoint = "https://c.y.qq.com/soso/fcgi-bin/client_search_cp" +
                "?new_json=1&format=json&inCharset=utf8&outCharset=utf-8" +
                "&platform=yqq.json&needNewCode=0&n=$PAGE_SIZE&p=$page&w=$keyword"
            val json = requestJson(endpoint)
            val data = json.optJSONObject("data")?.optJSONObject("song")
                ?.optJSONArray("list") ?: error("QQ 音乐目前无法返回搜索结果")
            buildList<QqSong> {
                for (i in 0 until data.length()) {
                    val item = data.optJSONObject(i) ?: continue
                    val mid = item.optString("mid").ifBlank { item.optString("songmid") }
                    if (!QqSong.isValidMid(mid)) continue
                    val singers = item.optJSONArray("singer")
                    val artist = buildList<String> {
                        if (singers != null) for (j in 0 until singers.length()) {
                            singers.optJSONObject(j)?.optString("name")?.takeIf { it.isNotBlank() }
                                ?.let { add(it) }
                        }
                    }.joinToString(" / ")
                    val album = item.optJSONObject("album")
                    add(QqSong(
                        mid = mid,
                        title = item.optString("name").ifBlank { item.optString("songname") }.take(150),
                        artist = artist.ifBlank { "未知歌手" }.take(150),
                        albumMid = album?.optString("mid").orEmpty(),
                        albumName = album?.optString("name").orEmpty().take(150)
                    ))
                }
            }.distinctBy { it.mid }
        }
    }

    /** Best-effort plain LRC query. If the public endpoint stops working, return a visible error. */
    suspend fun lyrics(mid: String): Result<String> = withContext(Dispatchers.IO) {
        networkResult {
            require(QqSong.isValidMid(mid)) { "歌曲编号不合法" }
            val endpoint = "https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg" +
                "?format=json&nobase64=1&songmid=$mid&g_tk=5381"
            val json = requestJson(endpoint)
            val original = json.optString("lyric").trim()
            require(original.isNotBlank()) { "暂无公开歌词或接口不可用" }
            val plain = if (original.contains("[00:") || original.contains("[01:")) original
                else runCatching { String(Base64.decode(original, Base64.DEFAULT), Charsets.UTF_8) }
                    .getOrDefault(original)
            val clean = plain.replace(Regex("<[^>]+>"), "").trim().take(80_000)
            require(clean.isNotBlank()) { "歌词为空" }
            clean
        }
    }

    // runCatching would silently turn coroutine cancellation into a UI network error.
    private inline fun <T> networkResult(block: () -> T): Result<T> = try {
        Result.success(block())
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (failure: Exception) {
        Result.failure(failure)
    }

    private fun java.io.Reader.readTextLimited(maxChars: Int): String {
        val buffer = CharArray(8192)
        val body = StringBuilder()
        while (body.length < maxChars) {
            val count = read(buffer, 0, minOf(buffer.size, maxChars - body.length))
            if (count < 0) break
            body.append(buffer, 0, count)
        }
        return body.toString()
    }

    private fun requestJson(endpoint: String): JSONObject {
        val conn = URL(endpoint).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 8_000
            conn.readTimeout = 9_000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36")
            conn.setRequestProperty("Referer", "https://y.qq.com/")
            conn.setRequestProperty("Accept", "application/json, text/javascript, */*")
            check(conn.responseCode in 200..299) { "QQ 音乐返回 HTTP ${conn.responseCode}" }
            val body = conn.inputStream.bufferedReader().use { it.readTextLimited(1_500_000) }.trim()
            // Some older public endpoints use JSONP even when 'format=json' is provided.
            val start = body.indexOf('{')
            val end = body.lastIndexOf('}')
            check(start >= 0 && end > start) { "服务器返回了非 JSON 数据" }
            return JSONObject(body.substring(start, end + 1))
        } finally {
            conn.disconnect()
        }
    }
}
