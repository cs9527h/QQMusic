package com.shuocao.qqmusic

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class UserPlaylist(val id: String, val name: String, val songIds: List<Long>, val createdAt: Long)

/** On-device playlists and listening history. Does not impersonate QQ Music cloud synchronization. */
class MusicStore(context: Context) {
    private val preferences = context.getSharedPreferences("qqmusic_personal_library_v1", Context.MODE_PRIVATE)

    fun playlists(): List<UserPlaylist> = runCatching {
        val json = JSONArray(preferences.getString("playlists", "[]") ?: "[]")
        buildList {
            for (i in 0 until json.length()) {
                val item = json.optJSONObject(i) ?: continue
                val songs = item.optJSONArray("songs") ?: JSONArray()
                add(UserPlaylist(
                    id = item.optString("id"), name = item.optString("name"),
                    songIds = (0 until songs.length()).map { songs.optLong(it) }.filter { it > 0L },
                    createdAt = item.optLong("createdAt")
                ))
            }
        }.filter { it.id.isNotBlank() && it.name.isNotBlank() }
    }.getOrDefault(emptyList())

    private fun save(playlists: List<UserPlaylist>) {
        val arr = JSONArray()
        playlists.forEach { playlist ->
            arr.put(JSONObject().put("id", playlist.id).put("name", playlist.name)
                .put("createdAt", playlist.createdAt).put("songs", JSONArray(playlist.songIds)))
        }
        preferences.edit().putString("playlists", arr.toString()).apply()
    }

    fun createPlaylist(name: String): List<UserPlaylist> {
        val clean = name.trim().take(80)
        if (clean.isBlank()) return playlists()
        val updated = playlists() + UserPlaylist(UUID.randomUUID().toString(), clean, emptyList(), System.currentTimeMillis())
        save(updated)
        return updated
    }

    fun renamePlaylist(id: String, name: String): List<UserPlaylist> {
        val clean = name.trim().take(80)
        if (clean.isBlank()) return playlists()
        return playlists().map { if (it.id == id) it.copy(name = clean) else it }.also(::save)
    }

    fun deletePlaylist(id: String): List<UserPlaylist> = playlists().filterNot { it.id == id }.also(::save)

    fun addSong(id: String, songId: Long): List<UserPlaylist> = playlists().map {
        if (it.id == id && songId !in it.songIds) it.copy(songIds = it.songIds + songId) else it
    }.also(::save)

    fun removeSong(id: String, songId: Long): List<UserPlaylist> = playlists().map {
        if (it.id == id) it.copy(songIds = it.songIds.filterNot { number -> number == songId }) else it
    }.also(::save)

    fun recordPlayed(songId: Long) {
        val history = history().filterNot { it == songId }
        preferences.edit().putString("history", JSONArray((listOf(songId) + history).take(70)).toString()).apply()
    }

    fun history(): List<Long> = runCatching {
        val data = JSONArray(preferences.getString("history", "[]") ?: "[]")
        (0 until data.length()).map { data.optLong(it) }.filter { it > 0L }
    }.getOrDefault(emptyList())

    fun saveLyric(songId: Long, text: String) {
        // Limit pathological files to keep shared preferences fast.
        preferences.edit().putString("lrc_$songId", text.take(100_000)).apply()
    }

    fun lyric(songId: Long): String = preferences.getString("lrc_$songId", null).orEmpty()
}

/** Supports both timestamped LRC and untimed plain lyric lines. */
data class LyricLine(val atMs: Long, val content: String)

object LyricParser {
    private val timestamp = Regex("\\[(\\d{1,3}):(\\d{2})(?:\\.(\\d{1,3}))?\\]")
    private val offsetTag = Regex("(?m)^\\[offset:([+-]?\\d+)\\]$", RegexOption.IGNORE_CASE)

    fun parse(source: String): List<LyricLine> {
        val timed = mutableListOf<LyricLine>()
        // LRC's offset tag adjusts all timestamps; clamp to prevent negative playback positions.
        val offsetMs = offsetTag.find(source)?.groupValues?.get(1)?.toLongOrNull()
            ?.coerceIn(-60_000L, 60_000L) ?: 0L
        for (line in source.lineSequence()) {
            val tags = timestamp.findAll(line).toList()
            val content = line.replace(timestamp, "").trim()
            if (content.isBlank()) continue
            for (tag in tags) {
                val min = tag.groupValues[1].toLongOrNull() ?: continue
                val sec = tag.groupValues[2].toLongOrNull() ?: continue
                if (sec !in 0L..59L) continue
                val fraction = tag.groupValues[3]
                val ms = when (fraction.length) {
                    1 -> fraction.toLong() * 100L
                    2 -> fraction.toLong() * 10L
                    3 -> fraction.toLong()
                    else -> 0L
                }
                timed.add(LyricLine(((min * 60 + sec) * 1000L + ms + offsetMs).coerceAtLeast(0L), content))
            }
        }
        if (timed.isNotEmpty()) return timed.sortedBy { it.atMs }
        return source.lineSequence().map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("[") }.take(1500)
            .mapIndexed { index, text -> LyricLine(index.toLong() * 3500L, text) }.toList()
    }
}
