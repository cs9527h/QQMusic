package com.shuocao.qqmusic

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Device-only bookmarks, not QQ Music cloud likes. No account tokens or cookies are stored. */
class OnlineLibraryStore(context: Context) {
    private val prefs = context.getSharedPreferences("qqmusic_online_library_v1", Context.MODE_PRIVATE)

    fun bookmarks(): List<QqSong> = runCatching {
        val array = JSONArray(prefs.getString("bookmarks", "[]"))
        buildList {
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val mid = obj.optString("mid")
                if (!QqSong.isValidMid(mid)) continue
                add(QqSong(
                    mid = mid,
                    title = obj.optString("title").take(150),
                    artist = obj.optString("artist").take(150),
                    albumMid = obj.optString("albumMid").take(40),
                    albumName = obj.optString("albumName").take(150)
                ))
            }
        }.distinctBy { it.mid }.take(500)
    }.getOrDefault(emptyList())

    fun toggle(song: QqSong): List<QqSong> {
        if (!QqSong.isValidMid(song.mid)) return bookmarks()
        val current = bookmarks()
        val next = if (current.any { it.mid == song.mid }) {
            current.filterNot { it.mid == song.mid }
        } else {
            (listOf(song) + current).take(500)
        }
        val json = JSONArray()
        next.forEach { item ->
            json.put(JSONObject().put("mid", item.mid).put("title", item.title)
                .put("artist", item.artist).put("albumMid", item.albumMid)
                .put("albumName", item.albumName))
        }
        prefs.edit().putString("bookmarks", json.toString()).apply()
        return next
    }

    fun searches(): List<String> = runCatching {
        val array = JSONArray(prefs.getString("searches", "[]"))
        (0 until array.length()).map { array.optString(it).take(100) }
            .filter { it.isNotBlank() }.distinct().take(12)
    }.getOrDefault(emptyList())

    fun recordSearch(keyword: String): List<String> {
        val clean = keyword.trim().take(100)
        if (clean.isBlank()) return searches()
        val next = (listOf(clean) + searches().filterNot { it.equals(clean, true) }).take(12)
        prefs.edit().putString("searches", JSONArray(next).toString()).apply()
        return next
    }

    fun clearSearches() { prefs.edit().remove("searches").apply() }
}

/** Conservative offline matching: a song must have an exact normalized title, not just a similar name. */
object LocalSongMatcher {
    private fun normalized(s: String): String = s.lowercase(java.util.Locale.ROOT)
        .replace(Regex("[\\s\\u3000]+"), "")
        .replace(Regex("[·•._-]"), "")

    fun match(remoteTitle: String, remoteArtist: String, local: List<LocalSong>): LocalSong? {
        val title = normalized(remoteTitle)
        if (title.isBlank()) return null
        val sameTitle = local.filter { normalized(it.title) == title }
        val artist = normalized(remoteArtist)
        if (artist.isBlank() || artist == "未知歌手") return sameTitle.singleOrNull()
        return sameTitle.firstOrNull {
            val localArtist = normalized(it.artist)
            localArtist.isNotBlank() && localArtist != "未知歌手" && (
                localArtist == artist || localArtist.contains(artist) || artist.contains(localArtist)
            )
        }
    }
}
