package com.shuocao.qqmusic

import android.net.Uri

data class LocalSong(
    val id: Long,
    val title: String,
    val artist: String,
    val albumId: Long,
    val uri: Uri,
    val durationMs: Long
)

data class QqSong(
    val mid: String,
    val title: String,
    val artist: String,
    val albumMid: String,
    val albumName: String = ""
) {
    companion object {
        private val safeMid = Regex("^[A-Za-z0-9]{5,40}$")
        fun isValidMid(mid: String): Boolean = safeMid.matches(mid)
    }
    val url: String get() = "https://y.qq.com/n/ryqq/songDetail/$mid"
    val cover: String? get() = albumMid.takeIf { it.isNotBlank() }
        ?.let { "https://y.gtimg.cn/music/photo_new/T002R300x300M000$it.jpg" }
}
