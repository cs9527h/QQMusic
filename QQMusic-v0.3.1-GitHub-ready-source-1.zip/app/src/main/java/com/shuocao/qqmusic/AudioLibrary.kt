package com.shuocao.qqmusic

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.ensureActive

object AudioLibrary {
    suspend fun load(context: Context): List<LocalSong> = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION
        )
        val songs = mutableListOf<LocalSong>()
        resolver.query(
            collection,
            projection,
            "${MediaStore.Audio.Media.IS_MUSIC} != 0",
            null,
            "${MediaStore.Audio.Media.DATE_ADDED} DESC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (cursor.moveToNext()) {
                kotlinx.coroutines.currentCoroutineContext().ensureActive()
                val duration = cursor.getLong(durationCol)
                if (duration < 1000L) continue
                val id = cursor.getLong(idCol)
                songs.add(LocalSong(
                    id = id,
                    title = cursor.getString(titleCol) ?: "未知歌曲",
                    artist = cursor.getString(artistCol) ?: "未知歌手",
                    albumId = cursor.getLong(albumCol),
                    uri = ContentUris.withAppendedId(collection, id),
                    durationMs = duration
                ))
            }
        }
        songs
    }
}
