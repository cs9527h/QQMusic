# Starter release build. Tighten rules once signed production releases are enabled.
