# QQMusic 参考项目审查（2026-11-19）

这份文档区分 **可直接做的本地功能**、**依赖易变第三方接口的功能**、**需要正式授权才能做的功能**。并不表示这些功能全部已经实现。

| 来源 | 许可证 | 已研究的主要内容 | 当前处理方式 |
|---|---|---|---|
| [Melodia](https://github.com/rinchao0721/Melodia) | MIT | Kotlin/Compose，Media3，动画，插件/音源模块、Koin、数据层 | 仅参考设计、体验及架构，不直接拷贝代码 |
| [Melodist](https://github.com/Viemean/melodist) | MIT | Kotlin 原生 QQ 音乐播放器、移动/TV、core-api/core-playback | 参考工程模块划分和播放边界；未移入未验证登录/媒体接口 |
| [QQMusicApi](https://github.com/L-1124/QQMusicApi) | GPL-3.0-or-later | Python QQ 音乐数据模块：song、album、search、lyric、songlist、user、login | 只研究公开数据字段与接口类别；未复制/嵌入 GPL Python 源码 |

## 已落地（v0.3.0，尚未编译和实机验收）

1. QQ 曲目公开检索、分页、查询错误回显。
2. 歌手/专辑按当前歌曲结果分组，并明确告知它们不是完整分类检索。
3. QQ 曲目信息的本机收藏、删除，独立于用户 QQ 音乐账号。
4. 本地最近搜索、清空记录。
5. 歌词公开接口读取尝试（接口易变、失败显示提示）。
6. 同名 + 歌手匹配本地音频时，出现「播放本地文件」按钮；正常 QQ 曲目点击依旧跳转官方。
7. Android 系统分享菜单。

## 未做与后续条件

- **QQ/微信登录**：没有合法授权的客户端身份与登录回调。不能把模拟官方应用签名/设备指纹的手段当作可靠的产品接入。
- **云歌单、会员与在线音频**：需要授权、许可、稳定的身份及媒体接口。第三方代码能够展示可能的协议形态，但不能提供合法的版权使用权和无条件稳定性。
- **逐字歌词/歌词翻译**：QQMusicApi 的一些格式返回加密或需要专门解析；现有代码只做简易 LRC 预览，不宣称完整逐字歌词。
- **完整 Spotify UI 与每一项功能**：Melodia 可借鉴架构和交互，当前项目仍是自研早期原型，没有 Spotify 的服务端能力或逐像素复刻。
- **许可证**：直接合并 MIT 源码时保留版权和 LICENSE；如整合 GPL 代码必须满足 GPL 的相应义务。QQ 音乐标识另有商标权问题。

## Android 验证标准

GitHub Actions 的 `lintDebug testDebugUnitTest assembleDebug` 全绿之后，再实测 Android 8/13/15+、权限拒绝、后台播放、歌曲数量千级、多次搜索和收藏的持久化。不要把未验证的功能宣称为稳定可用。
