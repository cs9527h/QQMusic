# Changelog

## v0.3.1 — 2026-11-19 (CI-ready review, no APK build)

- Fixed a MediaController lifecycle race: late asynchronous connect callbacks no longer update disposed UI state.
- Added coroutine cancellation checks during MediaStore scans and fixed QQ public API calls turning cancellation into misleading network errors.
- Bound QQ JSON network response read size to reduce accidental excessive memory allocation.
- Improved timed LRC parsing: supports `[offset:+/-N]`, clamps negative positions and rejects invalid seconds.
- Added two extra JUnit regression cases and passed four direct Kotlin lyric smoke tests without Android dependencies.
- Updated Android version to `0.3.1` / versionCode `5`, retaining applicationId `com.shuocao.qqmusic`.
- Fixed release-signing secret verification and split GitHub Actions build from tag publishing; read-only build permissions, write permissions only for tag publishing.
- Verified Android XML, workflow YAML, file integrity and Kotlin lexical syntax; **Android APK compile and device tests remain unrun** because SDK/download access is unavailable here.
- Confirmed GitHub connector can edit existing repositories but does not support creating a new repository; therefore no new repository or APK has yet been created.

## v0.3.0 — 2026-11-19 (source preview)

- Researched Melodia (MIT), Melodist (MIT) and QQMusicApi (GPL-3.0-or-later) and added an explicit attribution and integration design note.
- Added on-device QQ music metadata bookmarks and a dedicated library section. These **do not** synchronize with a QQ Music account.
- Added QQ public search history with a clear button and paginated search results.
- Added album and artist group views derived from song search results (not full server-side album/singer search).
- Added a best-effort public LRC preview with a transparent unavailable/error state.
- Added share options and optional exact local-audio matching; on-device matches play through Media3.
- Retained QQ official song deep links and explicitly excluded unauthorized membership streaming and DRM bypass.
- No full Android SDK build or physical-device smoke test was available in this environment; CI and device verification remain pending.

# QQMusic development log

## 0.2.1 — 2026-11-19
- Replace the self-designed launcher icon with QQ Music's yellow-circle/green-note brand emblem, prepared for standard and round Android launchers and adaptive masks.
- Bump Android versionCode to 3; keep applicationId unchanged.
- Independent third-party prototype; icon change does not confer official authorization.
- No APK build or device check performed in this environment.

## 0.2.0 — 2026-11-19
- Rename app to `QQMusic`; change package id to `com.shuocao.qqmusic`; preserve independent icon and third-party disclosure.
- Replace large promotional hero with a compact, streaming-style home: top filters, two-column recent tiles, collections, recent plays and personalized local music.
- Add browse genre cards and retain experimental QQ Music public metadata search + official song-detail link.
- Add persistent private playlists: create, rename, delete, add/remove songs.
- Add persistence for local playback history; keep previously implemented liked songs.
- Add shuffle, repeat modes, queue selection, LRC import/highlight and a four-action bottom bar.
- Improve Media3 service audio focus and noisy-headset handling.
- Add a unit test for LRC parsing; CI now runs lint, unit test and debug APK assembly.
- Add conditional stable signing support via GitHub Actions secrets and tag prereleases.
- Still **not implemented**: QQ account, QQ VIP, cloud sync, online song playback, protected audio or copyrighted content downloading; these need authorized APIs.
- Static checks completed. Android SDK and device validation pending.

## 0.1.0 — earlier prototype
- Initial native Compose UI, local music playback, QQ Music public metadata search, background media session and simple favorites.
